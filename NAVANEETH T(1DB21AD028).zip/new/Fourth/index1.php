<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">-->
    <link rel="stylesheet" href="index.css">
    <title>Category List</title>
</head>
<body><br><br>
    <div class="container">
        <header class="d-flex justify-content-between">
            <h1 class="head"><u>Category List</u></h1>
            <div ><a href="create.php" class="btn btn-primary">Add categories</a></div>
        </header>

        <!-- Search Widget -->
        <form action="" method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search by category id...">
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
        </form>

        <?php
        session_start();
        include("connect3.php");

        // Handle search query
        if(isset($_GET["search"])) {
            $search_query = $_GET["search"];
            $sql = "SELECT * FROM category WHERE cat_id LIKE '%$search_query%'";
            $result = mysqli_query($conn, $sql);

            if(mysqli_num_rows($result) > 0) {
                ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>CATEGORY ID</th>
                            <th>CATEGORY NAME</th>
                            <th>DESCRIPTION</th>
                            <th>Project ID</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while($row = mysqli_fetch_array($result)){
                            ?>
                            <tr>
                                <td><?php echo $row["cat_id"]; ?></td>
                                <td><?php echo $row["cat_name"]; ?></td>
                                <td><?php echo $row["description"]; ?></td>
                                <td><?php echo $row["id"]; ?></td>
                                <td>
                                    <a href="edit.php?id=<?php echo $row["cat_id"];?>" class="btn btn-warning">Edit</a>
                                    <a href="delete.php?id=<?php echo $row["cat_id"];?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php   
                        }
                        ?>
                    </tbody>
                </table>
                <?php
            } else {
                echo "<p>No results found.</p>";
            }
        } else { // If no search query, display all categories
            $sql = "SELECT * FROM category";
            $result = mysqli_query($conn, $sql);
            ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>CATEGORY ID</th>
                        <th>CATEGORY NAME</th>
                        <th>DESCRIPTION</th>
                        <th>Project ID</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while($row = mysqli_fetch_array($result)){
                        ?>
                        <tr>
                            <td><?php echo $row["cat_id"]; ?></td>
                            <td><?php echo $row["cat_name"]; ?></td>
                            <td><?php echo $row["description"]; ?></td>
                            <td><?php echo $row["id"]; ?></td>
                            <td>
                                <a href="edit.php?id=<?php echo $row["cat_id"];?>" class="btn btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row["cat_id"];?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
            <?php
        }
        ?>

        <a href="index.php" class="btn btn-warning">Back</a>
    </div>
    
</body>
</html>
