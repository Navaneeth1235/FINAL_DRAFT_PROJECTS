<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">-->
    <link rel="stylesheet" href="edit.css">
    <title>Edit Categories</title>
</head>
<body><br><br>
    <div class="container">
        <header class="d-flex justify-content-between my-4">
            <h1><u>Edit Categories Table</u></h1>
            <a href="index.php" class="btn btn-primary">Back</a>
        </header>
        <form action="process3.php" method="post">
        <?php
        if(isset($_GET["id"])){
            $id = $_GET["id"];
            include("connect3.php");
            $sql = "SELECT * FROM category WHERE cat_id = $id";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_array($result);
            ?>
             <div class="form-element my-4">
                <input type="text" class="form-control" name="cat_name" value="<?php echo $row["cat_name"];?>">
            </div>
            <div class="form-element my-4">
                <input type="text" class="form-control" name="description" value="<?php echo $row["description"];?>">
            </div>
            <div>
                <input type="hidden" value="<?php echo $row['cat_id'];?>" name="cat_id">
            </div>
            <div class="form-element">
                <input type="submit" class="btn btn-success" name="edit" value="Edit Task">
            </div>
        <?php
        }else{
            echo "<h1>No task selected</h1>";
        }
        ?>
        </form>
    </div>
    
</body>
</html>