<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];
    include("connect3.php");
    $sql = "DELETE FROM category WHERE cat_id = $id";
    if(mysqli_query($conn, $sql)){
        session_start();
        $_SESSION["create"] = "Category Deleted";
        header("Location: index.php");
    }
}



?>