<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">-->
    <link rel="stylesheet" href="index.css">
    <title>Category List</title>
</head>
<body><br><br>
    <div class="container">
        <header class="d-flex justify-content-between">
            <h1 class="head"><u>Category List</u></h1>
            <div >
                <a href="index1.php" class="btn btn-primary">Search</a>
                <a href="create.php" class="btn btn-primary">Add categories</a>
            </div>
        </header>
        <?php
        session_start();
        if (isset($_SESSION["create"])){
            ?>
            <div class="alert alert-success">
                <?php
                echo $_SESSION["create"];
                unset($_SESSION["create"]);
                ?>
            </div>
            <?php
        }
        ?>

        <?php
       
        if (isset($_SESSION["edit"])){
            ?>
            <div class="alert alert-success">
                <?php
                echo $_SESSION["edit"];
                unset($_SESSION["edit"]);
                ?>
            </div>
            <?php
        }
        ?>

        <?php
       
        if (isset($_SESSION["delete"])){
            ?>
            <div class="alert alert-success">
                <?php
                echo $_SESSION["delete"];
                unset($_SESSION["delete"]);
                ?>
            </div>
            <?php
        }
        ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>CATEGORY ID</th>
                    <th>CATEGORY NAME</th>
                    <th>DESCRIPTION</th>
                    <th>Project ID</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include("connect3.php");
                $sql = "SELECT * FROM category";
                $result = mysqli_query($conn, $sql);
                while($row = mysqli_fetch_array($result)){
                    ?>
                        <tr>
                            <td><?php echo $row["cat_id"]; ?></td>
                            <td><?php echo $row["cat_name"]; ?></td>
                            <td><?php echo $row["description"]; ?></td>
                            <td><?php echo $row["id"]; ?></td>
                            <td>
                                    <a href="edit.php?id=<?php echo $row["cat_id"];?>" class="btn btn-warning">Edit</a>
                                    <a href="delete.php?id=<?php echo $row["cat_id"];?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php   
                }
                ?>
            </tbody>
        </table>
        <a href="../home.php" class="btn btn-warning">Back to Home page</a>
    </div>
    
</body>
</html>