<?php
include("connect3.php");
if(isset($_POST["create"])){
    $cat = mysqli_real_escape_string($conn, $_POST['cat']);
    $cat_name = mysqli_real_escape_string($conn, $_POST['cat_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $id=mysqli_real_escape_string($conn, $_POST['id']);
    $sql= "INSERT INTO category (cat_id, cat_name, description, id) VALUES ('$cat', '$cat_name', '$description', '$id')";
    if(mysqli_query($conn, $sql)){
        session_start();
        $_SESSION["create"] = "Record Inserted";
        header("Location: index.php");
    }else{
        echo "something went wrong";
    }
}

if(isset($_POST["edit"])){
    $cat_name = mysqli_real_escape_string($conn, $_POST['cat_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $id = mysqli_real_escape_string($conn, $_POST['cat_id']);
    $sql= "UPDATE category SET cat_name ='$cat_name', description='$description' WHERE cat_id = $id";
    if(mysqli_query($conn, $sql)){
        session_start();
        $_SESSION["edit"] = "Category Updated";
        header("Location: index.php");
    }else{
        echo "something went wrong";
    }
}
?>