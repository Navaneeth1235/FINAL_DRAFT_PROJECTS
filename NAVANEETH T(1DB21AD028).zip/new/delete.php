<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];
    include("connect.php");
    $sql= "DELETE FROM project WHERE id = $id";
    if(mysqli_query($conn, $sql)){
        session_start();
        $_SESSION["delete"] = "Book Deleted Successfully ";
        header("Location: index1.php");
    }
}
?>