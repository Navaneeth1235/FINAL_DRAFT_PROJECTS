<?php

if(isset($_GET['id'])){
    $id=$_GET['id'];
    include("connect1.php");
    $sql = "DELETE FROM user WHERE user_id=$id";
    if(mysqli_query($conn,$sql)){
        session_start();
        $_SESSION["delete"] = "Project user deleted successfully";
        header("Location: index1.php");
    }
}
?>