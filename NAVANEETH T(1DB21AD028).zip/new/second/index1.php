<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">-->
    <link rel="stylesheet" href="index.css">
    <title>Project user's list</title>
</head>
<body><br><br>
<div class="container">
    <header class="d-flex justify-content-between my-4">
        <h1><u>Project user's info list</u></h1>
        <div>
            <a href="create.php" class="btn btn-primary">Add project user</a>
        </div>
    </header>

    <!-- Search Widget -->
    <form action="" method="GET" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by username...">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <?php
    session_start();
    include("connect1.php");

    // Handle search query
    if(isset($_GET["search"])) {
        $search_query = $_GET["search"];
        $sql = "SELECT * FROM user WHERE username LIKE '%$search_query%'";
        $result = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result) > 0) {
            ?>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>USER_ID</th>
                    <th>USERNAME</th>
                    <th>EMAIL</th>
                    <th>FULL NAME</th>
                    <th>ROLE</th>
                    <th>ACTION</th>
                </tr>
                </thead>
                <tbody>
                <?php
                while($row = mysqli_fetch_array($result)) {
                    ?>
                    <tr>
                        <td><?php echo $row["user_id"]; ?></td>
                        <td><?php echo $row["username"]; ?></td>
                        <td><?php echo $row["email"]; ?></td>
                        <td><?php echo $row["full_name"]; ?></td>
                        <td><?php echo $row["Role"]; ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $row["user_id"];?>" class="btn btn-warning">Edit</a>
                            <a href="delete.php?id=<?php echo $row["user_id"];?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
            <?php
        } else {
            echo "<p>No results found.</p>";
        }
    } else { // If no search query, display all users
        $sql = "SELECT * FROM user";
        $result = mysqli_query($conn, $sql);
        ?>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>USER_ID</th>
                <th>USERNAME</th>
                <th>EMAIL</th>
                <th>FULL NAME</th>
                <th>ROLE</th>
                <th>ACTION</th>
            </tr>
            </thead>
            <tbody>
            <?php
            while($row = mysqli_fetch_array($result)){
                ?>
                <tr>
                    <td><?php echo $row["user_id"]; ?></td>
                    <td><?php echo $row["username"]; ?></td>
                    <td><?php echo $row["email"]; ?></td>
                    <td><?php echo $row["full_name"]; ?></td>
                    <td><?php echo $row["Role"]; ?></td>
                    <td>
                        <a href="edit.php?id=<?php echo $row["user_id"];?>" class="btn btn-warning">Edit</a>
                        <a href="delete.php?id=<?php echo $row["user_id"];?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
        <?php
    }
    ?>
    <a href="index.php" class="btn btn-warning">Back</a>
</div>
</body>
</html>
