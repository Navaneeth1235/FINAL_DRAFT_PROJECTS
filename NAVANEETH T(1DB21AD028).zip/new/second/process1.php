<?php
include("connect1.php");
if(isset($_POST["create"])){
    $user_id=mysqli_real_escape_string($conn, $_POST["user-id"]);
    $username=mysqli_real_escape_string($conn, $_POST["username"]);
    $email=mysqli_real_escape_string($conn, $_POST["email"]);
    $full_name=mysqli_real_escape_string($conn, $_POST["full-name"]);
    $Role=mysqli_real_escape_string($conn, $_POST["Role"]);
    $sql1 = "INSERT INTO user (user_id, username, email, full_name, Role) VALUES ('$user_id', '$username', '$email', '$full_name', '$Role')";
    if(mysqli_query($conn, $sql1)){
        session_start();
        $_SESSION["create"] = "Project user added successfully";
        header("Location: index.php");
    }else{
        die("something went wrong");
    }
}

if(isset($_POST["edit"])){
    $username=mysqli_real_escape_string($conn, $_POST["username"]);
    $email=mysqli_real_escape_string($conn, $_POST["email"]);
    $full_name=mysqli_real_escape_string($conn, $_POST["full_name"]);
    $Role=mysqli_real_escape_string($conn, $_POST["Role"]);
    $id=mysqli_real_escape_string($conn, $_POST["user_id"]);
    $sql2 = "UPDATE user SET username = '$username', full_name= '$full_name', Role= '$Role' WHERE user_id = '$id'";
    if(mysqli_query($conn, $sql2)){
        session_start();
        $_SESSION["edit"] = "Project user edited successfully";
        header("Location: index.php");
    }else{
        die("something went wrong");
    }
}


?>