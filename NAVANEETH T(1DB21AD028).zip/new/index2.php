<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">-->
    <link rel="stylesheet" href="index1.css">
    <title>Project Management List</title>
</head>
<body>
<br><br>
<div class="container">
    <header class="d-flex justify-content-between my-4">
        <h1 class="head"><u>Project Management List</u></h1>
        <div>
            <a href="index1.php" class="btn btn-primary">Back</a>
        </div>
    </header>

    <!-- Search Widget -->
    <form action="" method="GET" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by title...">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <!-- PHP code to display search results -->
    <?php
    session_start();
    include("connect.php");

    // Handle search query
    if(isset($_GET["search"])) {
        $search_query = $_GET["search"];
        $sql = "SELECT * FROM project WHERE title LIKE '$search_query'";
        $result = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result) > 0) {
            ?>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Title</th>
                    <th>USN</th>
                    <th>Type</th>
                    <th>Manager</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                while($row = mysqli_fetch_array($result)) {
                    ?>
                    <tr>
                        <td><?php echo $row["title"]; ?></td>
                        <td><?php echo $row["USN"]; ?></td>
                        <td><?php echo $row["type"]; ?></td>
                        <td><?php echo $row["manager"]; ?></td>
                        <td><?php echo $row["status"]; ?></td>
                        <td>
                            <a href="view.php?id=<?php echo $row["id"]; ?>" class="btn btn-info">Read More</a>
                            <a href="edit.php?id=<?php echo $row["id"]; ?>" class="btn btn-warning">Edit</a>
                            <a href="delete.php?id=<?php echo $row["id"]; ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
            <?php
        } else {
            echo "<p>No results found.</p>";
        }
    }
    ?>
    <!-- End of PHP code -->

    <!--<a href="home.php" class="btn btn-warning">Back to Home page</a>-->
</div>
</body>
</html>
