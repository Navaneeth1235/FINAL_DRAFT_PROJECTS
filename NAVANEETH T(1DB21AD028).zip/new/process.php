<?php
include("connect.php");
if(isset($_POST["create"])){
    $id=mysqli_real_escape_string($conn, $_POST["id"]);
    $title=mysqli_real_escape_string($conn ,$_POST["title"]);
    $USN=mysqli_real_escape_string($conn ,$_POST["USN"]);
    $type=mysqli_real_escape_string($conn ,$_POST["type"]);
    $description=mysqli_real_escape_string($conn ,$_POST["description"]);
    $manager=mysqli_real_escape_string($conn ,$_POST["manager"]);
    $status=mysqli_real_escape_string($conn ,$_POST["status"]);
    $sql = "INSERT INTO project (id, title, USN, type, description, manager, status) VALUES ('$id', '$title', '$USN', '$type', '$description', '$manager', '$status')";
    if(mysqli_query($conn, $sql)){
        session_start();
        $_SESSION["create"] = "Book Added Successfully ";
        header("Location: index1.php");
    }else{
        die("Something went wrong");
    }
}
if(isset($_POST["edit"])){
    $title=mysqli_real_escape_string($conn ,$_POST["title"]);
    $USN=mysqli_real_escape_string($conn ,$_POST["USN"]);
    $type=mysqli_real_escape_string($conn ,$_POST["type"]);
    $description=mysqli_real_escape_string($conn ,$_POST["description"]);
    $manager=mysqli_real_escape_string($conn ,$_POST["manager"]);
    $status=mysqli_real_escape_string($conn ,$_POST["status"]);
    $id=mysqli_real_escape_string($conn ,$_POST["id"]);
    $sql = "UPDATE project SET title='$title', USN='$USN', type='$type', description='$description', manager='$manager', status='$status' WHERE id=$id";
    if(mysqli_query($conn, $sql)){
        session_start();
        $_SESSION["edit"] = "Book Updated Successfully ";
        header("Location: index1.php");
    }else{
        die("Something went wrong");
    }
}

?>