<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">-->
    <link rel="stylesheet" href="edit.css">
    <title>Edit Project</title>
</head>
<body><br><br><br><br>
    <div class="container">
        <header class="d-flex justify-content-between my-4">
            <h1 class="head"><u>Edit Project</u></h1>
            <div>
                <a href="index1.php" class="btn btn-primary">Back</a>
            </div>
        </header>
        <?php
        if(isset($_GET["id"])){
            $id=$_GET["id"];
            include("connect.php");
            $sql="SELECT * FROM project WHERE id=$id";  
            $result= mysqli_query($conn, $sql);
            $row=mysqli_fetch_array($result);

            ?>
            <form action="process.php" method="post">
            <div class="form-element my-4">
                <input type="text" class="form-control" name="title" value="<?php echo $row["title"];?>" placeholder="Project Title:">
            </div>
            <div class="form-element my-4">
                <input type="text" class="form-control" name="USN" value="<?php echo $row["USN"];?>" placeholder="USN:">
            </div>
            <div class="form-element my-4">
                <select name="type" class="form-control">
                    <option value="">Select type</option>
                    <option value="Software Development" <?php if($row['type']=="Software Development"){echo "selected";}?>>Software Development</option>
                    <option value="Machine Learning" <?php if($row['type']=="Machine Learning"){echo "selected";}?>>Machine Learning</option>
                    <option value="Data Science" <?php if($row['type']=="Data Science"){echo "selected";}?>>Data Science</option>
                    <option value="Web Development" <?php if($row['type']=="Web Development"){echo "selected";}?>>Web Development</option>
                </select>
            </div>
            <div class="form-element my-4">
                <input type="text" class="form-control" name="description" value="<?php echo $row["description"];?>" placeholder="Project Description:">
            </div>
            <div class="form-element my-4">
                <input type="text" class="form-control" name="manager" value="<?php echo $row["manager"];?>" placeholder="Project Manager">
            </div>
            <div class="form-element my-4">
                <input type="text" class="form-control" name="status" value="<?php echo $row["status"];?>" placeholder="Status:">
            </div>
            <input type="hidden" name="id" value='<?php echo $row['id'];?>'>
            <div class="form-element my-4">
                <input type="submit" class="btn btn-success" name="edit" value="Save">
            </div>
        </form>
        <?php
        }
        ?>
        
    </div>   
</body>
</html>