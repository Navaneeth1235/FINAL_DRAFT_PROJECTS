<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">-->
    <link rel="stylesheet" href="create.css">
    <title>Tasks</title>
</head>
<body><br><br>
    <div class="container">
        <header class="d-flex justify-content-between my-4">
            <h1><u>Tasks Table</u></h1>
            <a href="index.php" class="btn btn-primary">Back</a>
        </header>
        <form action="process2.php" method="post">
            <div class="form-element my-4">
                <input type="text" class="form-control" name="task" placeholder="Enter task number:">
            </div>
            <div class="form-element my-4">
                <input type="text" class="form-control" name="task_name" placeholder="Enter task name:">
            </div>
            <div class="form-element my-4">
                <input type="text" class="form-control" name="deadline" placeholder="Enter deadline:">
            </div>
            <div class="form-element my-4">
                <input type="text" class="form-control" name="status" placeholder="Enter status:">
            </div>
            <div class="form-element my-4">
                <input type="text" class="form-control" name="id" placeholder="Enter Project ID:">
            </div>
            <div class="form-element">
                <input type="submit" class="btn btn-success" name="create" value="Add Task">
            </div>
        </form>
    </div>
    
</body>
</html>