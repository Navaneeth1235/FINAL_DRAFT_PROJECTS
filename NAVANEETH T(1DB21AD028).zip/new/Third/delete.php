<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];
    include("connect2.php");
    $sql = "DELETE FROM tasks WHERE task_id = $id";
    if(mysqli_query($conn, $sql)){
        session_start();
        $_SESSION["delete"] = "Task Deleted Successfully";
        header("Location: index.php");
    }
}


?>