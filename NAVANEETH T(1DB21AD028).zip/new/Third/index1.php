<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-/lYG40LbxjQOzL6WCc5Qd/g5aSDl8A2QKfvd9ZGZ0w/+Q0HE60d+EBPaW99Y8IrW8qdmDtfCayChjLrM40L56w==" crossorigin="anonymous" />
    <link rel="stylesheet" href="index.css">
    <title>Tasks List</title>
    <style>
    </style>
</head>
<body><br><br><br>
    <div class="container">
        <header class="d-flex justify-content-between">
            <h1>Task's List</h1>
            <div ><a href="create.php" class="btn btn-primary">Add tasks</a></div>
        </header>

        <!-- Search Widget -->
        <form action="" method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search by task name...">
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
        </form>

        <?php
        session_start();
        include("connect2.php");

        // Handle search query
        if(isset($_GET["search"])) {
            $search_query = $_GET["search"];
            $sql = "SELECT * FROM tasks WHERE task_name LIKE '%$search_query%'";
            $result = mysqli_query($conn, $sql);

            if(mysqli_num_rows($result) > 0) {
                ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Task ID</th>
                            <th>Task</th>
                            <th>Deadline</th>
                            <th>Status</th>
                            <th>Project ID</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while($row = mysqli_fetch_array($result)){
                            ?>
                            <tr>
                                <td><?php echo $row["task_id"]; ?></td>
                                <td><?php echo $row["task_name"]; ?></td>
                                <td><?php echo $row["deadline"]; ?></td>
                                <td><?php echo $row["status"]; ?></td>
                                <td><?php echo $row["id"]; ?></td>
                                <td>
                                    <a href="edit.php?id=<?php echo $row["task_id"];?>" class="btn btn-warning">Edit</a>
                                    <a href="delete.php?id=<?php echo $row["task_id"];?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php   
                        }
                        ?>
                    </tbody>
                </table>
                <?php
            } else {
                echo "<p>No results found.</p>";
            }
        } else { // If no search query, display all tasks
            $sql = "SELECT * FROM tasks";
            $result = mysqli_query($conn, $sql);
            ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Task ID</th>
                        <th>Task</th>
                        <th>Deadline</th>
                        <th>Status</th>
                        <th>Project ID</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while($row = mysqli_fetch_array($result)){
                        ?>
                        <tr>
                            <td><?php echo $row["task_id"]; ?></td>
                            <td><?php echo $row["task_name"]; ?></td>
                            <td><?php echo $row["deadline"]; ?></td>
                            <td><?php echo $row["status"]; ?></td>
                            <td><?php echo $row["id"]; ?></td>
                            <td>
                                <a href="edit.php?id=<?php echo $row["task_id"];?>" class="btn btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row["task_id"];?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
            <?php
        }
        ?>

        <a href="index.php" class="btn btn-warning">Back</a>
    </div>
    
</body>
</html>
