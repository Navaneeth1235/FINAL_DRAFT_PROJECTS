<?php
include("connect2.php");
if(isset($_POST["create"])){
    $task = mysqli_real_escape_string($conn, $_POST["task"]);
    $task_name = mysqli_real_escape_string($conn, $_POST["task_name"]);
    $deadline = mysqli_real_escape_string($conn, $_POST["deadline"]);
    $status = mysqli_real_escape_string($conn, $_POST["status"]);
    $id= mysqli_real_escape_string($conn, $_POST["id"]);
    $sql = "INSERT INTO tasks (task_id, task_name, deadline, status, id) VALUES ('$task', '$task_name', '$deadline', '$status', '$id')";
    if(mysqli_query($conn, $sql)){
        session_start();
        $_SESSION["create"] = "Task Added Successfully ";
        header("Location: index.php");
    }else{
        die("Something went wrong");
    }
}

if(isset($_POST["edit"])){
    $task_name = mysqli_real_escape_string($conn, $_POST["task_name"]);
    $deadline = mysqli_real_escape_string($conn, $_POST["deadline"]);
    $status = mysqli_real_escape_string($conn, $_POST["status"]);
    $id = mysqli_real_escape_string($conn, $_POST["task_id"]);
    $sql3 = "UPDATE tasks SET task_name = '$task_name', deadline = '$deadline', status = '$status' WHERE task_id = '$id'";
    if(mysqli_query($conn, $sql3)){
        session_start();
        $_SESSION["update"] = "Task Updated Successfully ";
        header("Location: index.php");
    }else{
        die("Something went wrong");
    }
}

?>