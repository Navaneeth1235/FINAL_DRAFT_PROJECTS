<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Project Management System</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
      background-image: url(land_11.jpeg);
      background-size: cover;
      color: white;;
    }

    .container {
      display: flex;
    }

    .sidebar {
      width: 250px;
      background-color: #333;
      color: #fff;
      height: 100vh;
      position: fixed;
    }

    .main-content {
      margin-left: 250px;
      padding: 20px;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
    }

    .sidebar ul li {
      padding: 10px 20px;
      border-bottom: 1px solid #555;
    }

    .sidebar ul li a {
      text-decoration: none;
      color: #fff;
      display: block;
    }

    .sidebar ul li:hover {
      background-color: #555;
    }

    .logo {
      text-align: center;
      padding: 20px 0;
      font-size: 24px;
      font-weight: bold;
    }

    h1 {
      color: #333;
    }

    .button {
      display: inline-block;
      padding: 10px 20px;
      background-color: #007bff;
      color: #fff;
      text-decoration: none;
      border-radius: 5px;
      margin: 20px 10px;
      font-size: 18px;
      transition: background-color 0.3s;
    }

    .button:hover {
      background-color: #0056b3;
    }
    .head{
        justify-content: center;
        color: white;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <header>
    <div class="logo"><u>Project Management</u></div>
    <ul>
      <li><a href="home.php">Home</a></li>
      <li><a href="index1.php">Projects</a></li>
      <li><a href="./Third/index.php">Tasks</a></li>
      <li><a href="./Fourth/index.php">Categories</a></li>
      <li><a href="./second/index.php">Users</a></li>
      <li><a href="https://github.com/Navaneeth1235/DBMSforeignminiproject.git">Projects Github Link</a></li><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
      <li><a href="logout.php" class="btn btn-warning">Logout</a></li>
    </ul>
    </header>
    <footer>
    
    </footer>
    
  </div>
  <div class="main-content">
    <h1 class="head"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>WELCOME TO MY PROJECT MANAGEMENT SYSTEM</u></h1>
  </div>
  <div class="main-content">
    <!--<h3 class="head"><br><b></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"Effortlessly manage your projects from start to finish."</h3>
    <h3 class="head"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"Unlock the power of collaboration with our project management platform."</h3>
    <h3 class="head"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"Simplify project planning, tracking, and communication."</h3>
    <h3 class="head"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"Take control of your projects with our intuitive tools."</h3>
    <h3 class="head"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"Transform your project management experience with ease."</h3>-->
  </div>

  <script>
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    const openSidebar = document.querySelector('#openSidebar');
    const closeSidebar = document.querySelector('#closeSidebar');

    openSidebar.addEventListener('click', () => {
      sidebar.style.left = '0';
      mainContent.style.marginLeft = '250px';
    });

    closeSidebar.addEventListener('click', () => {
      sidebar.style.left = '-250px';
      mainContent.style.marginLeft = '0';
    });
  </script>
</body>
</html>
